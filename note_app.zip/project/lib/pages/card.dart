class NoteCard {
  String title;
  String note;
  DateTime date;

  NoteCard({this.title, this.note, this.date});
}
